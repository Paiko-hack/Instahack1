# 21/2/2018 Update - The whole code has been rewritten

# Instahack (Instabrute)
[![Donate](https://img.shields.io/badge/Donate-PayPal-green.svg)](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=ARVABYAUX3NPC)

### Please dont open a new issue before you search if issue already exists
### Please open issue with clear name

## How to use
Example: "python instabrute.py username passwords.txt"
```bash
python instabrute.py USERNAME PASSWORD_FILE
```
## Todo List
- [x] Finish the base
- [ ] Proxy things improvement

## Modules
argparse
requests
PySocks
asyncio
proxybroker

## Screenshots
###### [*] Hack instagram accounts use bruteforce
![alt tag](https://raw.githubusercontent.com/avramit/instahack/master/screenshot.png)
